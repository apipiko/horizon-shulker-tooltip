# Shulker Box Tooltip (Horizon native mod)

Shows the full contents of a shulker box in its tooltip (totals per item,
largest first), replacing vanilla's "first 5 items" list.

Original implementation for Horizon's `native_tooltip` hook (API 12),
inspired by MisterPeModder's ShulkerBoxTooltip (MIT). No code copied.

Limits of this first version: text only (no grid preview), item names are
English-style names made from the item id (not translated).
